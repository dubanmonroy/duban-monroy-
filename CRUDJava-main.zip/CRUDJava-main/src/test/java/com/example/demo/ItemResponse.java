package com.example.demo;

public class ItemResponse {
    private String item;

    // Getter y Setter
    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }
}